const mongoose = require('mongoose')

const Schema = mongoose.Schema

const userdata = new Schema({
    name: { type: String, default: '' },
    email:{ type: String, default:"xxx@gmail.com" },
    password: { type: String, default: '' },
    age
        : { type: String, default: '' },
    gender
        : { type: String, default: '' },


});
module.exports = mongoose.model("User", userdata);