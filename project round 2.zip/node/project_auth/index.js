// JavaScript source code
const { response } = require("express")
const express = require("express")
const mongoose = require("mongoose")
const app = express();
app.use(express.json())
require("dotenv/config")
const Port = process.env.PORT || 5000
app.listen(Port, () => {
    console.log("Listening to no one " + Port)
})
const connectionParams = {
    useNewUrlParser: true,
    useCreateIndex: true,
    useUnifiedTopology: true
}
mongoose.connect("mongodb+srv://Meghna:Megma123@cluster0.o5xyvsu.mongodb.net/Meghna?retryWrites=true&w=majority")
    .then(() => {
        console.log('Connected to database ')
    })
    .catch((err) => {
        console.error(`Error connecting to the database. \n${err}`);
    })

//Default First Page in Application
app.get("/", async (req, res) => {
    res.send("Holaa")
    res.end()
})

const users = require("./user")

app.post('/register', async (req, res) => {
    try {

        let user = await User.create(req.body);
        res.status(201).send(user);

    } catch (error) {

        res.status(500).send(error);
    }
})

app.post('/login', async (req, res) => {
    try {
        let { username, password } = req.body;
        let user = await User.findOne({ username: username, password: password });
        if (user) {
            res.status(200).send(user);
        }
        else {
            res.status(404).send('User not found');
        }

    } catch (error) {

        res.status(500).send(error);
    }
});

app.get('/users', async (req, res) => {
    try {
        let users = await User.find();
        res.status(200).send(users);
    } catch (error) {
        res.status(500).send(error);
    }
});
